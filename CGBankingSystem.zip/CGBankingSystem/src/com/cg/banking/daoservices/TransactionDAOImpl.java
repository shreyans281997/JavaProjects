package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.TransactionDB;
public class TransactionDAOImpl implements TransactionDAO {
	Account account=new Account();
@Override
	public Transaction save(Transaction transaction) {
		transaction.setTransactionId(TransactionDB.getTransactionID());
         return transaction;
	}
@Override
	public Transaction findOne(int transactionId) {
		return account.transactions.get(transactionId);
		}
@Override
	public List<Transaction> findAll() {
		//ArrayList<Integer> IdList=new ArrayList<>(TransactionDB.database.keySet());
		return null;
	}
}
