package com.cg.payroll.client;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
public static void main(String[] args) {
		PayrollServices services=new PayrollServicesImpl();
		int associateId1=services.acceptAssociateDetails("Shreyansh", "Jain", "reyj.028@gmail.com" ,"FSBU", "Analyst", "JD121", 100000, 600000, 21600, 15000, 634533, "AXIS Bank", "745675");
		int associateId2=services.acceptAssociateDetails("Shreyansh", "Jain", "reyj.028@gmail.com" ,"FSBU", "Analyst", "JD121", 2000, 12000, 1000, 10090, 634533, "AXIS Bank", "745675");
		System.out.println("Associate Id 1:- "+associateId1);
		System.out.println("Associate Id 2:- "+associateId2);
		System.out.println(services.getAllAssociatesDetails());
	     services.calculateNetSalary(101);
		System.out.println(services.getAssociateDetails(101));
	}
}
